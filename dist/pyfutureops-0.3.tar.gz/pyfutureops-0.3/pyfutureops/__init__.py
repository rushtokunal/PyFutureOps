# Version of the PyFutureOps package 
__version__= "0.0.3"
from pyfutureops.database import db_operations,db_tables
from pyfutureops.examples import multithread_wiki