class Class1(object):
    def __init__(self, url, verify=True):
        return 1